#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
    pid_t pid;

    // Cria o processo filho
    pid = fork();
    if (pid < 0) {
        // Erro ao criar o processo filho
        perror("fork");
        exit(EXIT_FAILURE);
    }
    if (pid == 0) {
        // C�digo do processo filho
        printf("Sou o processo filho. PID do filho: %d\n", getpid());
        // Substitui o processo filho pelo comando `sh -c "ls *.cpp"`
        printf("\nOi, eu sou um novo programa executado pelo Processo Filho, a seguir, estou listando os arquivos .cpp que est�o na pasta Laboratorio_03\n");
        execl("/bin/sh", "sh", "-c", "ls *.cpp", NULL);
        // Se execl retornar, significa que houve um erro
        perror("execl");
        exit(EXIT_FAILURE);
    } else {
        // C�digo do processo pai
        printf("\nSou o processo pai. PID do pai: %d\n", getpid());
        printf("PID do processo filho: %d\n", pid);
        // Aguarda o t�rmino do processo filho
        int status;
        if (wait(&status) == -1) {
            perror("wait");
            exit(EXIT_FAILURE);
        }
        if (WIFEXITED(status)) {
            printf("O processo filho terminou com c�digo de sa�da %d.\n", WEXITSTATUS(status));
        } else {
            printf("O processo filho terminou de forma anormal.\n");
        }
    }
    return 0;
}

