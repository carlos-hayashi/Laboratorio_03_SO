#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>

int main() {
    pid_t pid;
    // Cria o processo filho
    pid = fork();
    if (pid < 0) {
        // Erro ao criar o processo filho
        perror("fork");
        exit(EXIT_FAILURE);
    }
    if (pid == 0) {
        // C�digo do processo filho
        printf("Sou o processo filho. PID do filho: %d\n", getpid());
        // Loop para imprimir mensagem 5 vezes com intervalo de 1 segundo
        for (int i = 0; i < 5; i++) {
            printf("Mensagem %d do processo filho\n", i + 1);
            sleep(1); // Espera de 1 segundo
        }
        exit(EXIT_SUCCESS);
    } else {
        // C�digo do processo pai
        printf("Sou o processo pai. PID do pai: %d\n", getpid());
        printf("PID do processo filho: %d\n", pid);
        // Aguarda o t�rmino do processo filho
        wait(NULL);
        // Imprime mensagem informando que o processo filho terminou
        printf("O processo filho terminou sua execu��o.\n");
    }
    return 0;
}
